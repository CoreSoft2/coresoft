#!/bin/sh

pip update

pip install requests

pip install evdev

python -tt main.py

